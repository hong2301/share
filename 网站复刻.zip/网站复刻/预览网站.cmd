@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PORT=8099
echo.
echo   网站本地预览中...
echo   地址: http://127.0.0.1:%PORT%/
echo   关闭此窗口即停止服务
echo.
start "" http://127.0.0.1:%PORT%/
python -m http.server %PORT% --bind 127.0.0.1
