# 网站复刻说明

复刻源站：`https://hzycjt.cn/`（合智云创集团官网）
复刻时间：2026-10-13
复刻范围：同域名（`hzycjt.cn` / `www.hzycjt.cn`）下的全部页面与静态资源

## 复刻结果

| 项目 | 数量 |
|---|---|
| HTML 页面 | 60 |
| 静态资源（CSS/图片/图标等） | 35 |
| 总大小 | 约 4.2 MB |

- 页面覆盖：首页、服务（11 个）、案例（24 个）、博客（14 篇）、好处/流程/费用/FAQ/加盟/关于/联系/隐私/服务条款等
- 唯一缺失文件：`/apple-touch-icon.png` —— **原站本身就是 404**，并非抓取遗漏
- 链接完整性校验：2148 处内部引用，全部命中本地文件

## 目录结构

站点按原 URL 路径 1:1 落盘，例如：

```
/                         ->  index.html
/about                    ->  about/index.html
/services/qiye-shijiao    ->  services/qiye-shijiao/index.html
/cases/shandong-tech-500w ->  cases/shandong-tech-500w/index.html
/blog/xxx                 ->  blog/xxx/index.html
/_astro/Layout.xxx.css    ->  _astro/Layout.xxx.css
/cases/case1.jpg          ->  cases/case1.jpg
```

`_mirror/` 是复刻元数据（非站点内容）：

- `_manifest.tsv` — 每个抓取到的 URL、状态码、本地路径、字节数
- `_errors.tsv` — 抓取失败清单

## 本地预览

双击 **`预览网站.cmd`**，浏览器会自动打开 `http://127.0.0.1:8099/`。

> 必须用本地服务器打开，不能直接双击 `index.html`。因为站点内部链接与资源全部使用根路径（`/about`、`/_astro/...`），`file://` 协议下会解析到磁盘根目录。

## 技术特征

- 原站是 **Astro 静态导出**站点，托管在阿里云 OSS + ESA CDN
- **无后端依赖**：没有表单提交、没有 API 调用（`/api/` 只出现在预渲染规则的排除项里）
- **无外部 JS 文件**：全部交互逻辑内联在 HTML 的 `<script>` 标签中
- 全站样式集中在单个文件：`_astro/Layout.BVw46DmB.css`（约 85 KB）

## 修改时要注意的点

1. **绝对 URL**：正文链接都是根路径（`/about`），但 `<link rel="canonical">`、`og:url`、JSON-LD 结构化数据、`rss.xml`、`llms.txt` 里有约 2969 处 `https://www.hzycjt.cn` 绝对地址。换域名部署时需要批量替换。

2. **统计与 SEO 脚本**：页面里内联了百度统计（`hm.baidu.com`）、Google Tag Manager、Microsoft Clarity、Bing、IndexNow 等代码。本地打开会向这些平台发送请求 —— 如果要完全脱离原站，建议删掉这些 `<script>` 块。

3. **品牌信息**：公司名「合智云创集团」、Logo（`images/logo.png`）、电话 `17274887092`、微信二维码、ICP 备案号、`17274887092` 等散落在 60 个页面的页头/页脚中，属于模板化重复内容，改动时需要全站同步。

4. **样式**：改外观主要改 `_astro/Layout.BVw46DmB.css` 和页面内的 `<style>` 块（首页有一大段内联 CSS 定义变量 `--df-brand-*`）。
