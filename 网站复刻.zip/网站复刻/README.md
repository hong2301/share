# 网站复刻说明

复刻源站：`https://hzycjt.cn/`（合智云创集团官网）
复刻时间：2026-10-13
复刻范围：同域名（`hzycjt.cn` / `www.hzycjt.cn`）下的全部页面与静态资源

## 复刻结果

| 项目 | 数量 |
|---|---|
| HTML 页面 | 60 |
| 静态资源（CSS/图片/图标等） | 35 |
| 总大小 | 约 4.2 MB |

- 页面覆盖：首页、服务（11 个）、案例（24 个）、博客（14 篇）、好处/流程/费用/FAQ/加盟/关于/联系/隐私/服务条款等
- 唯一缺失文件：`/apple-touch-icon.png` —— **原站本身就是 404**，并非抓取遗漏
- 链接完整性校验：2148 处内部引用，全部命中本地文件

## 目录结构

站点按原 URL 路径 1:1 落盘，例如：

```
/                         ->  index.html
/about                    ->  about/index.html
/services/qiye-shijiao    ->  services/qiye-shijiao/index.html
/cases/shandong-tech-500w ->  cases/shandong-tech-500w/index.html
/blog/xxx                 ->  blog/xxx/index.html
/_astro/Layout.xxx.css    ->  _astro/Layout.xxx.css
/cases/case1.jpg          ->  cases/case1.jpg
```

`_mirror/` 是复刻元数据（非站点内容）：

- `_manifest.tsv` — 每个抓取到的 URL、状态码、本地路径、字节数
- `_errors.tsv` — 抓取失败清单
- `original-html.zip` — **路径转换前的原始 HTML 备份**（根路径写法，即原站原貌），想还原成完全原样时解压覆盖即可

## 打开方式

**直接双击 `index.html` 即可**（浏览器以 `file://` 打开），不需要任何服务器。

站点内部引用已全部转换为相对路径（`/about` → `about/index.html`、`/_astro/x.css` → `_astro/x.css`），所以 `file://` 下样式、图片、页面跳转都正常工作。

> 部署到 Web 服务器时相对路径同样可用，不需要改回去。

`预览网站.cmd` 仍保留：双击会启动本地 HTTP 服务器（`http://127.0.0.1:8099/`），适合需要 `http://` 协议的场景。

## 完整性校验

- 4566 处相对引用，**0 处解析失败**
- 残留根路径引用：0 处（`rel="canonical"`、`rel="alternate"` 等 SEO 元数据保持原样，不影响打开）
- 原站唯一 404 的 `/apple-touch-icon.png` 死引用已清除（60 个页面）

## 技术特征

- 原站是 **Astro 静态导出**站点，托管在阿里云 OSS + ESA CDN
- **无后端依赖**：没有表单提交、没有 API 调用（`/api/` 只出现在预渲染规则的排除项里）
- **无外部 JS 文件**：全部交互逻辑内联在 HTML 的 `<script>` 标签中
- 全站基础样式在单个文件：`_astro/Layout.BVw46DmB.css`（约 85 KB）；当前的白黑主题覆盖层在 `_astro/theme.css`（约 3 KB）

## 视觉主题（白黑版）

本站已从原站的蓝色企业风改造为 **白黑主题**，60 个页面完全统一（不是每页不同主题）：

| 项 | 原状 | 现在 |
|---|---|---|
| 主色 | 亮蓝 `#1f44d6` | 近黑 `#2b2b31` |
| 中性色 | 带蓝调的 ink 色板 | 纯中性灰（zinc 系） |
| 强调色 | 金色 `#ffc419` | 银灰 |
| 渐变 | hero / 按钮 / 深色区 / 光晕 / 金色徽章均有渐变 | **全部去除**，一律纯色 |
| Hero | 蓝色城市照片 + 浅蓝渐变淡出 | 城市照片保留，改为**灰度**（`background-blend-mode: luminosity`） |
| 圆角 | 按钮 6px / 卡片 8px | 按钮 10px / 卡片 16px |
| 阴影 | 带蓝调 | 纯中性黑，更柔更立体 |

做法分三层：

1. **`_astro/theme.css`**（主题层，在 `Layout.BVw46DmB.css` 之后加载）
   - 覆盖 `--df-brand-*` / `--df-ink-*` / `--df-accent-*` / `--df-radius-*` / `--df-shadow-*`
   - 把 Tailwind 的彩色族（`--color-amber/green/emerald/blue/red-*`）统一映射到中性灰阶
   - 用选择器规则压掉所有渐变
2. **各页内联色板**：每页 `<head>` 里的 `--df-brand-*` 十级色阶同步替换为白黑色板
3. **硬编码色清洗**：浮动侧边栏等内联样式里写死的 `#1f44d6`、slate 系色值全部换成中性灰

> **想换回蓝色或其它配色**：只需改 `_astro/theme.css` 的色板变量（10 个 brand + 11 个 ink + 3 个 accent），全站 60 页同步生效，再同步各页内联的那一行 `--df-brand-*` 即可。

### 有意保留原样的部分

- **Logo**（`images/logo.png`）仍是彩色图形，作为品牌标识未做灰度处理
- **内容图片**（案例资质截图、微信二维码）保留原色

## 修改时要注意的点

1. **绝对 URL**：正文链接已全部转为相对路径。但 `<link rel="canonical">`、`og:url`、JSON-LD 结构化数据、`rss.xml`、`llms.txt` 里仍有约 2900 处 `https://www.hzycjt.cn` 绝对地址（属 SEO 元数据，不影响浏览）。换域名部署时需要批量替换。

2. **统计与 SEO 脚本**：页面里内联了百度统计（`hm.baidu.com`）、Google Tag Manager、Microsoft Clarity、Bing、IndexNow 等代码。本地打开会向这些平台发送请求 —— 如果要完全脱离原站，建议删掉这些 `<script>` 块。

3. **品牌信息**：公司名「合智云创集团」、Logo（`images/logo.png`）、电话 `17274887092`、微信二维码、ICP 备案号、`17274887092` 等散落在 60 个页面的页头/页脚中，属于模板化重复内容，改动时需要全站同步。

4. **样式**：改外观主要改 `_astro/Layout.BVw46DmB.css` 和页面内的 `<style>` 块（首页有一大段内联 CSS 定义变量 `--df-brand-*`）。

5. **改完注意路径写法**：页面里引用资源要用相对当前页面的路径（页面在 `cases/foo/index.html` 时，引用图片写 `../../cases/case1.jpg`），不要写成 `/cases/case1.jpg`，否则双击打开会失效。
