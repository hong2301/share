# 网站复刻说明

复刻源站：`https://hzycjt.cn/`（原「合智云创集团」官网）
复刻时间：2026-10-13
当前版本：已改造为「潍坊中税银企企业管理咨询服务有限公司」官网（2026-10-14）
复刻范围：同域名（`hzycjt.cn` / `www.hzycjt.cn`）下的全部页面与静态资源

## 复刻结果

| 项目 | 数量 |
|---|---|
| HTML 页面 | 60 |
| 静态资源（CSS/图片/图标等） | 35 |
| 总大小 | 约 4.2 MB |

- 页面覆盖：首页、服务（11 个）、案例（24 个）、博客（14 篇）、好处/流程/费用/FAQ/加盟/关于/联系/隐私/服务条款等
- 唯一缺失文件：`/apple-touch-icon.png` —— **原站本身就是 404**，并非抓取遗漏
- 链接完整性校验：2148 处内部引用，全部命中本地文件

## 目录结构

站点按原 URL 路径 1:1 落盘，例如：

```
/                         ->  index.html
/about                    ->  about/index.html
/services/qiye-shijiao    ->  services/qiye-shijiao/index.html
/cases/shandong-tech-500w ->  cases/shandong-tech-500w/index.html
/blog/xxx                 ->  blog/xxx/index.html
/_astro/Layout.xxx.css    ->  _astro/Layout.xxx.css
/cases/case1.jpg          ->  cases/case1.jpg
```

`_mirror/` 是复刻元数据（非站点内容）：

- `_manifest.tsv` — 每个抓取到的 URL、状态码、本地路径、字节数
- `_errors.tsv` — 抓取失败清单
- `original-html.zip` — **路径转换前的原始 HTML 备份**（根路径写法，即原站原貌），想还原成完全原样时解压覆盖即可

## 打开方式

**直接双击 `index.html` 即可**（浏览器以 `file://` 打开），不需要任何服务器。

站点内部引用已全部转换为相对路径（`/about` → `about/index.html`、`/_astro/x.css` → `_astro/x.css`），所以 `file://` 下样式、图片、页面跳转都正常工作。

> 部署到 Web 服务器时相对路径同样可用，不需要改回去。

`预览网站.cmd` 仍保留：双击会启动本地 HTTP 服务器（`http://127.0.0.1:8099/`），适合需要 `http://` 协议的场景。

## 完整性校验

- 4566 处相对引用，**0 处解析失败**
- 残留根路径引用：0 处（`rel="canonical"`、`rel="alternate"` 等 SEO 元数据保持原样，不影响打开）
- 原站唯一 404 的 `/apple-touch-icon.png` 死引用已清除（60 个页面）

## 技术特征

- 原站是 **Astro 静态导出**站点，托管在阿里云 OSS + ESA CDN
- **无后端依赖**：没有表单提交、没有 API 调用（`/api/` 只出现在预渲染规则的排除项里）
- **无外部 JS 文件**：全部交互逻辑内联在 HTML 的 `<script>` 标签中
- 全站基础样式在单个文件：`_astro/Layout.BVw46DmB.css`（约 85 KB）；当前的白蓝主题覆盖层在 `_astro/theme.css`（约 1.7 KB）

## 客户信息（2026-10-14 改造）

站点已由原「合智云创」改造为 **潍坊中税银企企业管理咨询服务有限公司**（简称「中税银企」）。

| 项 | 现在 |
|---|---|
| 公司全称 | 潍坊中税银企企业管理咨询服务有限公司 |
| 简称 | 中税银企 |
| Logo | `images/logo.png`（蓝色图形，已换成客户提供的新 logo） |
| 导航栏 / 页脚标识 | logo 图形 + `BANKING ENTERPRISES` + 中税银企（按客户样式图实现，字色 `#3756BF`） |
| 联系电话 | `0536 7366878`（链接 `tel:05367366878`） |
| 邮箱 | `liuguopeng@zhongshuiyinqi.cn` |
| 专属顾问 | 刘经理 |
| 联系二维码 | `images/qr-personal.png`（个人微信）—— **企业二维码与微信号文本已全部移除** |
| 隐私政策 / 服务条款地址 | 山东省潍坊市奎文区 |
| 关于页 | 企业简介与使命愿景按客户提供文案重写 |
| 页脚 | 已移除「官网由登峰增长搭建及提供SEO/GEO优化支持」一句 |

> 旧的 `images/wechat-personal.jpg`、`images/wechat-enterprise.jpg` 已删除。

### 占位项（拿到正式信息后替换）

- **ICP 备案号**：已改为占位 `鲁ICP备00000000号`，替换真实备案号即可（60 页）
- **域名**：全站已占位为 `www.zhongshuiyinqi.cn`（约 3034 处），覆盖 `canonical` / `og:url` / JSON-LD / `rss.xml` / `llms.txt` / `robots.txt`，拿到正式域名后批量替换

### 已彻底移除的商业推广

「登峰增长」(dfgrow.com) 已全部清掉：页脚「增长支持」链接（60）、JSON-LD 站点导航项（60）、`about` / `cases` 页底部推荐区块（2）、`llms.txt` 条目 — 全站已无 `dfgrow` / `登峰` 字样。

## 首页结构（2026-10-19 调整）

**区块顺序**：

1. Hero —「用知识产权代替现金，零资金压力完成注册资本实缴」+ 节省计算器
   （底部 4 个数据卡已移除，数据背书统一交给下方「数字见证实力」；
   城市背景图已彻底移除，Hero 为纯白底，无渐变、无伪元素光晕）
2. **数字见证实力**（深色数据区，全页唯一的数据区）
3. 企业注册资本实缴的四大痛点
4. 企业实缴 — 解决方案
5. **关于中税银企**（简介 + 资质标签 + 4 个能力卡 + 双按钮）
6. 六大核心优势
7. 成功案例
8. 客户评价
9. 常见问题
10. CTA

**文案调整**：Hero 新增「中小企业公共服务平台」标签；CTA 文案加入「中税银企」品牌名。

**内页**：59 个内页在 `</main>` 前统一插入紧凑版「关于中税银企」信任条（简介 + 双按钮）。

> ⚠️ 维护须知：原站 CSS 是按需编译的 Tailwind，**新加内容只能使用 CSS 里已存在的类名**（如 `lg:grid-cols-2` / `gap-12` 就不存在，用了会丢样式）。自行定义的布局类写在 `_astro/theme.css`（如 `.about-brand-grid`）。

## 视觉主题（白蓝版）

本站已从原站蓝色风改为 **白蓝主题**，60 个页面完全统一（不是每页不同主题）：

| 项 | 原状 | 现在 |
|---|---|---|
| 主色 | 亮蓝 `#1f44d6`（偏紫） | 蓝 `#2563eb`（去紫调，更清爽） |
| 浅色区块底 | 浅蓝 `#eff1fa` | 浅蓝 `#eff6ff`（保持蓝调，**不做灰化**） |
| 中性色 / 强调色 / 彩色图标 | 站点原值 | **一律沿用原值**（金色点缀、绿色勾选、三色标签均保留） |
| 渐变 | hero / 按钮 / 深色区 / 光晕 / 金色徽章均有渐变 | **全部去除**，一律纯色 |
| Hero | 蓝色城市照片 + 浅蓝渐变淡出 | **照片已移除**，纯白底（全站统一） |
| 圆角 | 按钮 6px / 卡片 8px | 按钮 10px / 卡片 16px |
| 阴影 | 带蓝调 | 蓝色调柔和阴影 |

做法分两层：

1. **`_astro/theme.css`**（主题层，在 `Layout.BVw46DmB.css` 之后加载）
   - 只覆盖 `--df-brand-*`（白蓝色板）与 `--df-radius-*` / `--df-shadow-*`
   - 用选择器规则压掉残留渐变（深色统计区、金色徽章、Tailwind 渐变工具类）
   - Hero 的渐变/光晕/背景图已在 `Layout.BVw46DmB.css` 本体中删除（`.hero-gradient` 现为纯白 `#fff`），theme.css 不再需要覆盖 hero
   - **不碰**中性色、强调色、彩色族，避免上一版“满屏灰”的问题
2. **各页内联色板**：每页 `<head>` 里的 `--df-brand-*` 十级色阶同步替换为白蓝色板

> **想换其它配色**：改 `_astro/theme.css` 的 11 个 `--df-brand-*` 变量，再同步各页内联的那一行 `--df-brand-*` 即可，全站 60 页生效。

## 修改时要注意的点

0. **【已修复的坑】原站 `a:hover` 配色缺陷**
   原站有一条 `a:hover { color: var(--color-brand-700) }`，其特异性 **(0,1,1)** 高于 `.text-white` 的 (0,1,0)，会把**所有链接** hover 时的文字强制染成深蓝。而蓝色实心按钮（`bg-brand-600 text-white hover:bg-brand-700`）hover 后背景正好也是同一个深蓝 → **蓝底蓝字完全看不见**（手机上点一下会粘住 hover，最容易发现）。全站 218 个按钮受影响。
   已在 `_astro/theme.css` 用更高特异性 (0,2,1) 修复：
   ```css
   a.text-white:hover, a.text-white:active, a.text-white:focus-visible { color: #fff; }
   ```
   **后续新增按钮时**：如果用 `text-white` + `hover:bg-*`，这条规则会自动保护；如果用的是其它文字色，记得检查 hover 后是否被 `a:hover` 染色。

1. **绝对 URL**：正文链接已全部转为相对路径。但 `<link rel="canonical">`、`og:url`、JSON-LD 结构化数据、`rss.xml`、`llms.txt` 里仍有约 2900 处 `https://www.hzycjt.cn` 绝对地址（属 SEO 元数据，不影响浏览）。换域名部署时需要批量替换。

2. **统计与 SEO 脚本**：页面里内联了百度统计（`hm.baidu.com`）、Google Tag Manager、Microsoft Clarity、Bing、IndexNow 等代码。本地打开会向这些平台发送请求 —— 如果要完全脱离原站，建议删掉这些 `<script>` 块。

3. **品牌信息**：公司名「合智云创集团」、Logo（`images/logo.png`）、电话 `17274887092`、微信二维码、ICP 备案号、`17274887092` 等散落在 60 个页面的页头/页脚中，属于模板化重复内容，改动时需要全站同步。

4. **样式**：改外观主要改 `_astro/Layout.BVw46DmB.css` 和页面内的 `<style>` 块（首页有一大段内联 CSS 定义变量 `--df-brand-*`）。

5. **改完注意路径写法**：页面里引用资源要用相对当前页面的路径（页面在 `cases/foo/index.html` 时，引用图片写 `../../cases/case1.jpg`），不要写成 `/cases/case1.jpg`，否则双击打开会失效。

6. **补齐的工具类**：`_astro/theme.css` 末尾已补 `.gap-2.5`（页头/页脚 logo 间距）、`.w-52` / `.h-52`（联系页二维码 208px）。这三个是原站 Tailwind 按需编译时漏掉的，新增布局时优先复用已有类名。

7. **Logo 尺寸**：`images/logo.png` 已从 785×780 / 238 KB 压缩为 161×160 / 23 KB（显示高度 40px，4x 屏足够）。原图备份在 `_mirror/logo-original.png`，需要替换时覆盖回去即可。
